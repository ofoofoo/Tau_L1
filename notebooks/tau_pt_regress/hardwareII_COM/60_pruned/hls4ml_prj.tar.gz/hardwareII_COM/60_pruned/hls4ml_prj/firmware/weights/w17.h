//Numpy array shape [10, 1]
//Min -2.798828125000
//Max 1.773437500000
//Number of zeros 6

#ifndef W17_H_
#define W17_H_

#ifndef __SYNTHESIS__
weight17_t w17[10];
#else
weight17_t w17[10] = { 0.000000,  1.773438,  1.755859,  0.000000,  0.000000,  0.000000,  1.603516,  0.000000, -2.798828,  0.000000};
#endif

#endif
