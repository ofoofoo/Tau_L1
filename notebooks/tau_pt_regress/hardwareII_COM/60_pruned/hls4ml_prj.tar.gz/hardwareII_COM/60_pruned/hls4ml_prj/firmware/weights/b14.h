//Numpy array shape [10]
//Min -0.031250000000
//Max 0.250000000000
//Number of zeros 0

#ifndef B14_H_
#define B14_H_

#ifndef __SYNTHESIS__
bias14_t b14[10];
#else
bias14_t b14[10] = {0.031250, 0.015625, 0.046875, -0.015625, -0.031250, 0.046875, 0.203125, 0.015625, 0.250000, -0.015625};
#endif

#endif
