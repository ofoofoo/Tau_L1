//Numpy array shape [1]
//Min -0.714843750000
//Max -0.714843750000
//Number of zeros 0

#ifndef B17_H_
#define B17_H_

#ifndef __SYNTHESIS__
bias17_t b17[1];
#else
bias17_t b17[1] = {-0.714844};
#endif

#endif
